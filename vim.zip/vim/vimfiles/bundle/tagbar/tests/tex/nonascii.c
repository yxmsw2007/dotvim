int Plodenie = 0;
char *Klíčenie = "blah";
short Zrenie;
long Žatva;
