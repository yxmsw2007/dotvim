import foo
import bar

defaultdict(lambda: 0)
classofhello = 0

class test(foo, bar):
    class Inner:
#        pass
        def foo(self):
            print "Inner"
#    pass

def test():
    class Inner2:
        def bar(self):
            print "Inner2"
#    t = Inner2()
#    pass

#print "Test"
#r = test.Inner2()
#test()
