class Class1
  def fun1()
    foo = if bar
            baz
          end
  end

  def fun2()
  end
end
