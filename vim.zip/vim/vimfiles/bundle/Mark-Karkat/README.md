Mark-Karkat
===========